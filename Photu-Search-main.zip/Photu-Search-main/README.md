# Photu-Search
A simple photo search app in React
